# 3.0 稳定版

# 3.1 增加了 时间记录器 记录文件标记

# 3.2 logs 文件 loss 增加custom_str 【epoch50 出现loss陡增 = 不可去掉第一段】

# 3.3 weights 文件保存 = 间隔保存 = interval_save 

# 3.4【epoch50 出现loss陡增 = 不可去掉第一段】 试验测试 Freeze_Epoch 合适的值 = 10~20