import os 
import numpy as np 
import torch 
import torch.backends.cudnn as cudnn
import torch.optim as optim 
import shutil, collections, time  # 修改2021.09.09
import datetime # 修改2021.09.10

from torch.utils.data import DataLoader
from tqdm import tqdm

from nets.frcnn import FasterRCNN 
from trainer import FasterRCNNTrainer 
from utils.dataloader import FRCNNDataset, frcnn_dataset_collate 
from utils.utils import LossHistory_interrupt, weights_init 



def get_lr(optimizer): 
    for param_group in optimizer.param_groups: 
        return param_group['lr'] 

# 文件复制 == 附加 == 可不用 
def copyDir(sourcePath, targetPath):
    if not os.path.isdir(sourcePath):
        return '源目录不存在'
    # 创建两个栈,一个用来存放原目录路径,另一个用来存放需要复制的目标目录
    sourceStack = collections.deque()
    sourceStack.append(sourcePath)
    targetStack = collections.deque()
    targetStack.append(targetPath)
    # 创建一个循环当栈里面位空时结束循环
    while True:
        if len(sourceStack) == 0:
            break
        # 将路径从栈的上部取出
        sourcePath = sourceStack.pop()  # sourcePath = sourceStack.popleft()
        # 遍历出该目录下的所有文件和目录
        listName = os.listdir(sourcePath)

        # 将目录路径取出来
        targetPath = targetStack.pop()  # targetPath = targetStack.popleft()
        # 判断该目标目录是否存在,如果不存在就创建
        if not os.path.isdir(targetPath):
            os.makedirs(targetPath)
        # 遍历目录下所有文件组成的列表,判断是文件,还是目录
        for name in listName:
            # 拼接新的路径
            sourceAbs = os.path.join(sourcePath, name)
            targetAbs = os.path.join(targetPath, name)
            # 判断是否时目录
            if os.path.isdir(sourceAbs):
                # 判断目标路径是否存在,如果不存在就创建一个
                if not os.path.exists(targetAbs):
                    os.makedirs(targetAbs)
                # 将新的目录添加到栈的顶部
                sourceStack.append(sourceAbs)
                targetStack.append(targetAbs)
            # 判断是否是文件
            if os.path.isfile(sourceAbs):
                shutil.copyfile(sourceAbs,targetAbs)

# 删除文件夹下所有文件
def del_file(filepath):
    """
    删除某一目录下的所有文件或文件夹
    :param filepath: 路径
    :return:
    """
    del_list = os.listdir(filepath)
    for f in del_list:
        file_path = os.path.join(filepath, f)
        if os.path.isfile(file_path):
            os.remove(file_path)
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)

## 函数 权重.pth文件仅保存epoch降排序的前5个 # 2021.09.07 修改
## 保留loss最小的权重 = 保留val_loss最小的权重 # 2021.09.08 修改
## 函数优化 2021.09.08
## 增加了间隔次数interval_save 保存 2021.09.10
## 增加训练第一阶段最后一次.pth 2021.09.20
def weightFile_seletedsave(): #权重.pth文件仅保存epoch降排序的前3个 # 2021.09.07 修改
    import os 
    rootpath = './logs/'
    files = os.listdir(rootpath )  
    file_weight_pth = []
    file_weight_pth_save =[] #保留权重路径
    interval_save = 30

    for file_pth in files:
        if os.path.splitext(file_pth)[1]=='.pth':
            file_weight_pth.append(file_pth)
            if int(file_pth[5:8]) % interval_save  == 0: ## 增加了间隔次数interval_save 保存 2021.09.10
               file_weight_pth_save.append( file_pth ) 
            if int(file_pth[5:8]) == 14: ## 增加训练第一阶段最后一次.pth 2021.09.20
               file_weight_pth_save.append( file_pth )    
    
    file_weight_pth.sort(key=lambda ele:ele[19:25], reverse=False)  
    file_weight_pth_save.append( file_weight_pth[0] )#保留loss最小的权重
    file_weight_pth.sort(key=lambda ele:ele[34:40], reverse=False)
    file_weight_pth_save.append( file_weight_pth[0] )#保留loss最小的权重
    file_weight_pth.sort(key=lambda ele:ele[5:8], reverse=True)     # sort epoch
    file_weight_pth_save.extend( file_weight_pth[:3] )#保留loss最小的权重

    for pth_file in file_weight_pth:
        if pth_file not in file_weight_pth_save:
            os.remove(os.path.join(rootpath ,pth_file))


## 增加backbone = 修改时间 2021.09.02         
def fit_ont_epoch(net,epoch,epoch_size,epoch_size_val,gen,genval,Epoch,cuda,backbone,custom_str): 
    total_loss   = 0 
    rpn_loc_loss = 0 
    rpn_cls_loss = 0 
    roi_loc_loss = 0 
    roi_cls_loss = 0 
    val_toal_loss = 0 
    start_runtime = datetime.datetime.now() #修改 2021.09.10

    with tqdm(total=epoch_size,desc=f'Epoch {epoch + 1}/{Epoch}',postfix=dict,mininterval=0.3) as pbar:
        for iteration, batch in enumerate(gen): 
            if iteration >= epoch_size: 
                break
            imgs, boxes, labels = batch[0], batch[1], batch[2] 
            with torch.no_grad(): 
                if cuda:
                    imgs = torch.from_numpy(imgs).type(torch.FloatTensor).cuda() 
                else:
                    imgs = torch.from_numpy(imgs).type(torch.FloatTensor) 

            losses = train_util.train_step(imgs, boxes, labels, 1) 
            rpn_loc, rpn_cls, roi_loc, roi_cls, total = losses 
            total_loss += total.item() 
            rpn_loc_loss += rpn_loc.item() 
            rpn_cls_loss += rpn_cls.item()
            roi_loc_loss += roi_loc.item()
            roi_cls_loss += roi_cls.item()
            
            pbar.set_postfix(**{'total'    : total_loss / (iteration + 1), 
                                'rpn_loc'  : rpn_loc_loss / (iteration + 1),  
                                'rpn_cls'  : rpn_cls_loss / (iteration + 1), 
                                'roi_loc'  : roi_loc_loss / (iteration + 1), 
                                'roi_cls'  : roi_cls_loss / (iteration + 1), 
                                'lr'       : get_lr(optimizer)})
            pbar.update(1)

    print('Start Validation') 
    with tqdm(total=epoch_size_val, desc=f'Epoch {epoch + 1}/{Epoch}',postfix=dict,mininterval=0.3) as pbar:
        for iteration, batch in enumerate(genval): 
            if iteration >= epoch_size_val:
                break
            imgs,boxes,labels = batch[0], batch[1], batch[2]
            with torch.no_grad():
                if cuda:
                    imgs = torch.from_numpy(imgs).type(torch.FloatTensor).cuda()
                else:
                    imgs = torch.from_numpy(imgs).type(torch.FloatTensor)

                train_util.optimizer.zero_grad()
                losses = train_util.forward(imgs, boxes, labels, 1)
                _, _, _, _, val_total = losses

                val_toal_loss += val_total.item()

            pbar.set_postfix(**{'total_loss': val_toal_loss / (iteration + 1)})
            pbar.update(1)
    
    end_runtime = datetime.datetime.now() #修改 2021.09.10
    # 修改epoch = epoch+1, backbone=backbone, starttime=start_runtime, endtime= end_runtime 2021.09.10
    loss_history.append_loss(total_loss/(epoch_size+1), val_toal_loss/(epoch_size_val+1), 
                            epoch = epoch+1,backbone=backbone,custom_str=custom_str,starttime=start_runtime, endtime= end_runtime) 
    print('Finish Validation') 
    print('Epoch:'+ str(epoch+1) + '/' + str(Epoch)) 
    print('Total Loss: %.4f || Val Loss: %.4f ' % (total_loss/(epoch_size+1),val_toal_loss/(epoch_size_val+1))) 
    print('Saving state, iter:', str(epoch+1)) 
    # 修改Epoch 编号 == str(epoch+1).zfill(3)  ## 增加backbone = 修改时间 2021.09.02
    # 保存模型= NEW = 权重 + 优化器（增加） + epoch 【仅pth，中断训练后loss陡增】 修改2021.09.09
    state = {'model':model.state_dict(), 'optimizer':optimizer.state_dict(), 'epoch': epoch+1}
    torch.save(state, 'logs/Epoch%s-Total_Loss%.4f-Val_Loss%.4f-%s-%s.pth'%(str(epoch+1).zfill(3),total_loss/(epoch_size+1),val_toal_loss/(epoch_size_val+1),backbone,custom_str))
    weightFile_seletedsave() #权重.pth文件仅保存epoch降排序的前3个+loss最小+val_loss最小  # 2021.09.08 修改

## 函数 权重文件路径排序与索引中断前一次的权重文件
def Get_weightFile():
    import os
    files = os.listdir('./logs')  
    file_weight_pth = []
    for file in files:
        if os.path.splitext(file)[1]=='.pth':
            file_weight_pth.append(file)
    file_weight_pth.sort(key=lambda ele:ele[5:8], reverse=True)
    if len(file_weight_pth) == 0:
        return print('no Get_weightFile')
    else:
        return file_weight_pth[0]
## 获得训练中断标记
def Get_InterruptFlag_FindweightFile():
    import os
    files = os.listdir('./logs')  
    file_weight_pth = []
    for file in files:
        if os.path.splitext(file)[1]=='.pth':
            file_weight_pth.append(file)
    file_weight_pth.sort(key=lambda ele:ele[5:8], reverse=True)
    if len(file_weight_pth) == 0:  #无'pth'文件 = 无中断
        return False             
    else:
        return True           #有'pth'文件 = 有中断

if __name__ == "__main__":                  
    for NUM_SelectImage in range(0,7):    #递增训练 NUM_SelectIncrementalImage = NUM_SelectImage
        #-------------------------------#
        #   是否使用Cuda
        #   没有GPU可以设置成False
        #-------------------------------#
        Cuda = True
        #----------------------------------------------------# 
        #   训练之前一定要修改NUM_CLASSES
        #   修改成所需要区分的类的个数。
        #----------------------------------------------------# 
        NUM_CLASSES = 1    # classes = ["pitaya"]   位置：voc2frcnn_NYL.py
        #-------------------------------------------------------------------------------------#
        #   input_shape是输入图片的大小，默认为800,800,3，随着输入图片的增大，占用显存会增大
        #   视频上为600,600,3，实际测试中发现800,800,3效果更好
        #-------------------------------------------------------------------------------------#
        input_shape = [800,800,3]
        #----------------------------------------------------#
        #   使用到的主干特征提取网络 backbone
        #   'vgg16'  = "resnet50" = 'mobilenetV3'
        #   # NetWeight_Select =['voc_vgg16.pth','voc_weights_resnet.pth', 'voc_mobilenet_v3.pth'] # 无训练时，已有训练好的权重选择，不使用
        #    
        #----------------------------------------------------#
        Netbackbone_Select = ['vgg16','resnet50', 'mobilenetV3'] # [0 1 2] 
        Net_SelectNum = 1          # [0 = 'vgg16',  1='resnet50',  2='mobilenetV3'] 
        backbone = Netbackbone_Select[Net_SelectNum]  
        
        load_pretrained_weight_init = True        # epoch = 0 时 是否加载预训练权重 = voc2007 数据集权重
        pretrained_NetWeight_Select =['voc_weights_vgg.pth','voc_weights_resnet.pth', 'voc_mobilenet_v3.pth']  # 2='voc_mobilenet_v3.pth' 不匹配

        
        #图片数量 = 递增 = 列表
        Flag_Incremental_training = True  # 图像递增训练测试 = True / False
        list_Number_pictures = [10,20,50,100,300,500,700,910] 
        NUM_SelectIncrementalImage = NUM_SelectImage  # for 循坏 
        

        # 自定义训练类型 ['Rb' 'Ori']  # 对应的数据集不同  
        custom_str = 'Rb' + 'IncTr' + str(list_Number_pictures[NUM_SelectIncrementalImage])



        model = FasterRCNN(NUM_CLASSES,backbone=backbone)  
        weights_init(model)

        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')  
        # #------------------------------------------------------#
        #   权值文件请看README，百度网盘下载  
        #------------------------------------------------------#
        Flag_interrupt = Get_InterruptFlag_FindweightFile();  #存在权重文件pth, 中断后继续训练 = 设置为1
        
        
        if Flag_interrupt: 
            model_path = os.path.join('logs/', Get_weightFile())
    
            checkpoint = torch.load(model_path)
            model.load_state_dict(checkpoint['model'])
            # optimizer.load_state_dict(checkpoint['optimizer']) #加载optimizer = 放在后面 
            # start_epoch = int(Get_weightFile()[5:8]) # 当前训练次数 # 测试用 
            start_epoch = checkpoint['epoch']       
            epoch_Cur = start_epoch                    
            print('model_path', model_path)         
            print('epoch_Cur_init', epoch_Cur) 
            print('Loading weights into state dict...')      
            
        else:
            epoch_Cur = 0 
            if load_pretrained_weight_init:
                model_path = os.path.join('model_data/', pretrained_NetWeight_Select[Net_SelectNum])
                device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') 
                model_dict = model.state_dict() 
                pretrained_dict = torch.load(model_path, map_location=device) 
                pretrained_dict = {k: v for k, v in pretrained_dict.items() if np.shape(model_dict[k]) ==  np.shape(v)} 
                model_dict.update(pretrained_dict) 
                model.load_state_dict(model_dict)  
                print('Only First Epoch =Loading pretrained weights =%s'%pretrained_NetWeight_Select[Net_SelectNum]) 
                print('Finished!') 

        net = model.train()
    
        if Cuda:
            net = torch.nn.DataParallel(model) 
            cudnn.benchmark = True 
            net = net.cuda() 

        # 损失记录器 # ## 修改 LossHistory_interrupt 增加：backbone + Flag_interrupt = 2021.09.10
        loss_history = LossHistory_interrupt("logs/", backbone=backbone, custom_str = custom_str ,Flag_interrupt = Flag_interrupt)   

        #----------------------------------------------------------------------#
        #   读取训练数据集 train_lines + 验证数据集 val_lines
        #----------------------------------------------------------------------#
    
        # 训练集 读取
        train_annotation_path = '2007_train.txt'  
        with open(train_annotation_path) as f:  
            train_lines = f.readlines()  
        np.random.seed(10101) 
        np.random.shuffle(train_lines)  
        np.random.seed(None) 
        num_train = len(train_lines)  # 获取训练集数量

        #图片数量递增 = 是否使用
        if Flag_Incremental_training:
            train_lines_IncTrain = train_lines[:list_Number_pictures[NUM_SelectIncrementalImage]]
            train_lines = train_lines_IncTrain  # 更新训练图片
            num_train = len(train_lines)  # 获取训练集数量
        
        #Txt文件记录 #训练图片索引 + 数量
        with open(os.path.join('logs/','ftrain_param.txt'), 'a') as f:
            f.write('num_train: ' + str(num_train) + '\n')  #训练数量
            for i in train_lines:
                # print(i)
                f.write(str(i)) #训练图片索引 

        #验证集 读取
        val_annotation_path = '2007_val.txt'
        with open(val_annotation_path) as f:
                val_lines = f.readlines() 
        np.random.seed(10101) 
        np.random.shuffle(val_lines)  
        np.random.seed(None)
        num_val=len(val_lines)       # 获取验证集数量  

        #------------------------------------------------------#
        #   主干特征提取网络特征通用，冻结训练可以加快训练速度  
        #   也可以在训练初期防止权值被破坏    
        #   Init_Epoch 为起始世代   
        #   Freeze_Epoch 为冻结训练的世代   
        #   Unfreeze_Epoch 总训练世代   
        #   提示OOM或者显存不足请调小Batch_size
        #   试验测试 Freeze_Epoch 合适的值 = 10~20
        #-----------------------------------------------------#
        #定义参数的数值 Freeze_Epoch 
        Val_Freeze_Epoch, Val_Unfreeze_Epoch =15, 300     
        # Val_Freeze_Epoch, Val_Unfreeze_Epoch =1, 3  #测试用


        if  epoch_Cur < Val_Freeze_Epoch:    
            lr              = 1e-4    
            Batch_size      = 2  # 2 根据GTX显存大小设定    
            Init_Epoch      = epoch_Cur        # Init_Epoch = 0
            Freeze_Epoch    = Val_Freeze_Epoch  

            #记录训练参数 
            with open(os.path.join('logs/','ftrain_param.txt'), 'a') as f:
                f.write('one_stage_lr: ' + str(lr) + '\n')  #训练数量
                f.write('one_stage_Batch_size: ' + str(Batch_size) + '\n')  #训练数量

            optimizer       = optim.Adam(net.parameters(), lr, weight_decay=5e-4)       
            if Flag_interrupt: #中断后，继续训练 # 加载optimizer参数  修改 2021.09.09      
                optimizer.load_state_dict(checkpoint['optimizer'])   

            lr_scheduler    = optim.lr_scheduler.StepLR(optimizer,step_size=1,gamma=0.95)  

            train_dataset   = FRCNNDataset(train_lines, (input_shape[0], input_shape[1]), is_train=True)    
            val_dataset     = FRCNNDataset(val_lines, (input_shape[0], input_shape[1]), is_train=False)     
            gen             = DataLoader(train_dataset, shuffle=True, batch_size=Batch_size, num_workers=4, pin_memory=True,
                                    drop_last=True, collate_fn=frcnn_dataset_collate)
            gen_val         = DataLoader(val_dataset, shuffle=True, batch_size=Batch_size, num_workers=4, pin_memory=True,
                                    drop_last=True, collate_fn=frcnn_dataset_collate)
                            
            epoch_size      = num_train // Batch_size          
            epoch_size_val  = num_val // Batch_size              

            if epoch_size == 0 or epoch_size_val == 0:  
                raise ValueError("数据集过小，无法进行训练，请扩充数据集。")     

            # ------------------------------------# 
            #   冻结一定部分训练
            # ------------------------------------# 
            for param in model.extractor.parameters(): 
                param.requires_grad = False 

            # ------------------------------------#
            #   冻结bn层
            # ------------------------------------#
            model.freeze_bn()

            train_util      = FasterRCNNTrainer(model, optimizer)

            for epoch in range(Init_Epoch,Freeze_Epoch):
                fit_ont_epoch(net,epoch,epoch_size,epoch_size_val,gen,gen_val,Freeze_Epoch,Cuda,backbone,custom_str) ## 增加backbone = 修改时间 2021.09.02
                lr_scheduler.step()
                epoch_Cur = epoch + 1  #更新当前epoch_Cur 



        if  epoch_Cur >= Val_Freeze_Epoch:
            lr              = 1e-5
            Batch_size      = 2  # 2 根据GTX显存大小设定
            Freeze_Epoch    = epoch_Cur         # 2021.09.08 修改
            Unfreeze_Epoch  = Val_Unfreeze_Epoch
            
            #记录训练参数 
            with open(os.path.join('logs/','ftrain_param.txt'), 'a') as f:
                f.write('two_stage_lr: ' + str(lr) + '\n')  #训练数量
                f.write('two_stage_Batch_size: ' + str(Batch_size) + '\n')  #训练数量


            if Flag_interrupt:
                optimizer       = optim.Adam(net.parameters(), lr, weight_decay=5e-4)        
                optimizer.load_state_dict(checkpoint['optimizer'])  # 加载optimizer参数  修改 2021.09.09  #if Flag_interrupt:  


            lr_scheduler    = optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.95)

            train_dataset   = FRCNNDataset(train_lines, (input_shape[0], input_shape[1]), is_train=True)
            val_dataset     = FRCNNDataset(val_lines, (input_shape[0], input_shape[1]), is_train=False)
            gen             = DataLoader(train_dataset, shuffle=True, batch_size=Batch_size, num_workers=4, pin_memory=True,
                                    drop_last=True, collate_fn=frcnn_dataset_collate)
            gen_val         = DataLoader(val_dataset, shuffle=True, batch_size=Batch_size, num_workers=4, pin_memory=True,
                                    drop_last=True, collate_fn=frcnn_dataset_collate)
                            
            epoch_size      = num_train // Batch_size
            epoch_size_val  = num_val // Batch_size
            
            if epoch_size == 0 or epoch_size_val == 0:
                raise ValueError("数据集过小，无法进行训练，请扩充数据集。")
                
            #------------------------------------#
            #   解冻后训练
            #------------------------------------#
            for param in model.extractor.parameters(): 
                param.requires_grad = True 

            # ------------------------------------#
            #   冻结bn层
            # ------------------------------------#
            model.freeze_bn() 

            train_util      = FasterRCNNTrainer(model,optimizer) 

            for epoch in range(Freeze_Epoch,Unfreeze_Epoch):
                fit_ont_epoch(net,epoch,epoch_size,epoch_size_val,gen,gen_val,Unfreeze_Epoch,Cuda,backbone,custom_str)## 增加backbone = 修改时间 2021.09.02
                lr_scheduler.step() 
                
            

            # 训练完毕后备份到指定文件夹
            Image_path = [  "../Train_weight_save/HLG_Rb_weight/Rb_vgg16_weight",    
                    "../Train_weight_save/HLG_Rb_weight/Rb_res50_weight", 
                    "../Train_weight_save/HLG_Rb_weight/Rb_mobv3_weight"  ]
            source_path = './logs'   # 源路径

            if Flag_Incremental_training:  # 递增训练=是否选择
                    IncTrain_path = 'IncTrain_'+ str(NUM_SelectIncrementalImage) + '_'+ str(list_Number_pictures[NUM_SelectIncrementalImage])
                    target_path = os.path.join(Image_path[ Net_SelectNum ] , IncTrain_path ) #目标路径
            else:
                    target_path = Image_path[ Net_SelectNum ]   #目标路径
            copyDir(source_path, target_path)  #复制文件（多级文件夹）
            # 删除log里所有文件
            if Flag_Incremental_training:  # 递增训练=是
                # 删除文件夹下所有文件
                del_file(source_path)





