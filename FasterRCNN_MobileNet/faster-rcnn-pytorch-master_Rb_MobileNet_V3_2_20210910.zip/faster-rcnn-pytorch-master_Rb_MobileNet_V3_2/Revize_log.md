# 3.0 稳定版

# 3.1 增加了 时间记录器 记录文件标记

# 3.2 logs 文件 loss 增加custom_str



